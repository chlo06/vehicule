let mercedes = new Voiture ("CF-501-MM" , "pink" , 1500 , 110 , 60.0 , 5 )

console.log(mercedes)

console.log(mercedes.repeindre('red'))
console.log(mercedes.mettreEssence(30))
console.log(mercedes.seDeplacer (10, 4))
console.log(mercedes.addInsurance(true))

console.log(mercedes)
console.log(mercedes.toString)